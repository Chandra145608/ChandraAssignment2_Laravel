<table border="1px solid black" >
    <tr>
        <td> This mail is delievered by {{$name}}</td>
    </tr>
    <tr>
        <td> {{$data}}</td>
    </tr>
</table>